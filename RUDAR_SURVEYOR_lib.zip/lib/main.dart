import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:share_plus/share_plus.dart';

void main() {
  runApp(const RudarSurveyorApp());
}

class RudarSurveyorApp extends StatelessWidget {
  const RudarSurveyorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'RUDAR SURVEYOR',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}

class SurveyRecord {
  final String owner;
  final String village;
  final String taluka;
  final String surveyNo;
  final String date;
  final String payment;
  final String mobile;

  SurveyRecord({
    required this.owner,
    required this.village,
    required this.taluka,
    required this.surveyNo,
    required this.date,
    required this.payment,
    required this.mobile,
  });

  Map<String, dynamic> toJson() => {
        'owner': owner,
        'village': village,
        'taluka': taluka,
        'surveyNo': surveyNo,
        'date': date,
        'payment': payment,
        'mobile': mobile,
      };

  factory SurveyRecord.fromJson(Map<String, dynamic> json) => SurveyRecord(
        owner: json['owner'] ?? '',
        village: json['village'] ?? '',
        taluka: json['taluka'] ?? '',
        surveyNo: json['surveyNo'] ?? '',
        date: json['date'] ?? '',
        payment: json['payment'] ?? '',
        mobile: json['mobile'] ?? '',
      );
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<SurveyRecord> records = [];

  @override
  void initState() {
    super.initState();
    loadRecords();
  }

  Future<void> loadRecords() async {
    final prefs = await SharedPreferences.getInstance();
    final list = prefs.getStringList('survey_records') ?? [];
    setState(() {
      records = list
          .map((e) => SurveyRecord.fromJson(jsonDecode(e)))
          .toList();
    });
  }

  Future<void> saveRecords() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(
      'survey_records',
      records.map((e) => jsonEncode(e.toJson())).toList(),
    );
  }

  Future<void> addRecord() async {
    final record = await Navigator.push<SurveyRecord>(
      context,
      MaterialPageRoute(builder: (_) => const SurveyFormScreen()),
    );
    if (record != null) {
      setState(() => records.add(record));
      await saveRecords();
    }
  }

  Future<void> editRecord(int index) async {
    final record = await Navigator.push<SurveyRecord>(
      context,
      MaterialPageRoute(
        builder: (_) => SurveyFormScreen(record: records[index]),
      ),
    );
    if (record != null) {
      setState(() => records[index] = record);
      await saveRecords();
    }
  }

  Future<void> deleteRecord(int index) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Delete Record'),
        content: const Text('શું આ રેકોર્ડ delete કરવો છે?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (ok == true) {
      setState(() => records.removeAt(index));
      await saveRecords();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'RUDAR SURVEYOR',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: RefreshIndicator(
        onRefresh: loadRecords,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Colors.blue, Colors.indigo],
                ),
                borderRadius: BorderRadius.circular(24),
              ),
              child: const Column(
                children: [
                  Icon(Icons.my_location, color: Colors.white, size: 58),
                  SizedBox(height: 10),
                  Text(
                    'RUDAR SURVEYOR',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 26,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 6),
                  Text(
                    'જમીન માપણી અને સર્વે માટેની એપ',
                    style: TextStyle(color: Colors.white, fontSize: 16),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            MenuCard(
              icon: Icons.landscape,
              title: 'જમીન માપણી માહિતી',
              subtitle: 'નવો રેકોર્ડ ઉમેરો અને જૂના રેકોર્ડ જુઓ',
              onTap: addRecord,
            ),
            const SizedBox(height: 12),
            MenuCard(
              icon: Icons.calculate,
              title: 'જમીનનું Calculator',
              subtitle: 'Length × Width થી ક્ષેત્રફળ ગણો',
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const CalculatorScreen(),
                  ),
                );
              },
            ),
            const SizedBox(height: 24),
            const Text(
              'Saved Records',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            if (records.isEmpty)
              const Card(
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: Center(
                    child: Text('હજુ કોઈ રેકોર્ડ સેવ થયેલ નથી.'),
                  ),
                ),
              ),
            ...List.generate(records.length, (index) {
              final r = records[index];
              return Card(
                child: ListTile(
                  leading: const CircleAvatar(
                    child: Icon(Icons.person),
                  ),
                  title: Text(r.owner),
                  subtitle: Text(
                    'ગામ: ${r.village} • સર્વે: ${r.surveyNo}',
                  ),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => RecordViewScreen(record: r),
                      ),
                    );
                  },
                  trailing: PopupMenuButton<String>(
                    onSelected: (value) async {
                      if (value == 'view') {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => RecordViewScreen(record: r),
                          ),
                        );
                      } else if (value == 'edit') {
                        await editRecord(index);
                      } else if (value == 'delete') {
                        await deleteRecord(index);
                      } else if (value == 'pdf') {
                        await createAndSharePdf(r);
                      }
                    },
                    itemBuilder: (_) => const [
                      PopupMenuItem(
                        value: 'view',
                        child: Text('View'),
                      ),
                      PopupMenuItem(
                        value: 'edit',
                        child: Text('Edit'),
                      ),
                      PopupMenuItem(
                        value: 'delete',
                        child: Text('Delete'),
                      ),
                      PopupMenuItem(
                        value: 'pdf',
                        child: Text('Generate / Share PDF'),
                      ),
                    ],
                  ),
                ),
              );
            }),
            const SizedBox(height: 20),
            const Center(
              child: Text(
                'Customer Care: Y.M. DHUNDHALAVA\n8487847474',
                textAlign: TextAlign.center,
                style: TextStyle(fontWeight: FontWeight.w600),
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: addRecord,
        icon: const Icon(Icons.add),
        label: const Text('નવો રેકોર્ડ'),
      ),
    );
  }
}

class MenuCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const MenuCard({
    super.key,
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 3,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Row(
            children: [
              CircleAvatar(
                radius: 28,
                child: Icon(icon, size: 30),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(subtitle),
                  ],
                ),
              ),
              const Icon(Icons.arrow_forward_ios, size: 18),
            ],
          ),
        ),
      ),
    );
  }
}

class SurveyFormScreen extends StatefulWidget {
  final SurveyRecord? record;

  const SurveyFormScreen({super.key, this.record});

  @override
  State<SurveyFormScreen> createState() => _SurveyFormScreenState();
}

class _SurveyFormScreenState extends State<SurveyFormScreen> {
  late final TextEditingController owner;
  late final TextEditingController village;
  late final TextEditingController taluka;
  late final TextEditingController surveyNo;
  late final TextEditingController date;
  late final TextEditingController payment;
  late final TextEditingController mobile;

  @override
  void initState() {
    super.initState();
    final r = widget.record;
    owner = TextEditingController(text: r?.owner ?? '');
    village = TextEditingController(text: r?.village ?? '');
    taluka = TextEditingController(text: r?.taluka ?? '');
    surveyNo = TextEditingController(text: r?.surveyNo ?? '');
    date = TextEditingController(text: r?.date ?? '');
    payment = TextEditingController(text: r?.payment ?? '');
    mobile = TextEditingController(text: r?.mobile ?? '');
  }

  @override
  void dispose() {
    owner.dispose();
    village.dispose();
    taluka.dispose();
    surveyNo.dispose();
    date.dispose();
    payment.dispose();
    mobile.dispose();
    super.dispose();
  }

  Future<void> selectDate() async {
    final selected = await showDatePicker(
      context: context,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
      initialDate: DateTime.now(),
    );
    if (selected != null) {
      date.text =
          '${selected.day.toString().padLeft(2, '0')}/${selected.month.toString().padLeft(2, '0')}/${selected.year}';
      setState(() {});
    }
  }

  void save() {
    if (owner.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('માલિકનું નામ દાખલ કરો.')),
      );
      return;
    }

    Navigator.pop(
      context,
      SurveyRecord(
        owner: owner.text.trim(),
        village: village.text.trim(),
        taluka: taluka.text.trim(),
        surveyNo: surveyNo.text.trim(),
        date: date.text.trim(),
        payment: payment.text.trim(),
        mobile: mobile.text.trim(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final editing = widget.record != null;
    return Scaffold(
      appBar: AppBar(
        title: Text(editing ? 'રેકોર્ડ Edit કરો' : 'જમીન માપણી માહિતી'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          AppTextField(
            controller: owner,
            label: 'માલિકનું નામ',
            icon: Icons.person,
          ),
          AppTextField(
            controller: village,
            label: 'ગામ',
            icon: Icons.location_city,
          ),
          AppTextField(
            controller: taluka,
            label: 'તાલુકો',
            icon: Icons.map,
          ),
          AppTextField(
            controller: surveyNo,
            label: 'સર્વે નંબર',
            icon: Icons.numbers,
          ),
          TextField(
            controller: date,
            readOnly: true,
            onTap: selectDate,
            decoration: InputDecoration(
              labelText: 'તારીખ',
              prefixIcon: const Icon(Icons.calendar_month),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
              ),
            ),
          ),
          const SizedBox(height: 14),
          AppTextField(
            controller: payment,
            label: 'પેમેન્ટ',
            icon: Icons.currency_rupee,
            keyboardType: const TextInputType.numberWithOptions(
              decimal: true,
            ),
          ),
          AppTextField(
            controller: mobile,
            label: 'મોબાઇલ નંબર',
            icon: Icons.phone,
            keyboardType: TextInputType.phone,
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 54,
            child: FilledButton.icon(
              onPressed: save,
              icon: const Icon(Icons.save),
              label: Text(
                editing ? 'Update' : 'Save',
                style: const TextStyle(fontSize: 18),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class AppTextField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final IconData icon;
  final TextInputType? keyboardType;

  const AppTextField({
    super.key,
    required this.controller,
    required this.label,
    required this.icon,
    this.keyboardType,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: TextField(
        controller: controller,
        keyboardType: keyboardType,
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: Icon(icon),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
          ),
        ),
      ),
    );
  }
}

class RecordViewScreen extends StatelessWidget {
  final SurveyRecord record;

  const RecordViewScreen({super.key, required this.record});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Survey Report'),
        actions: [
          IconButton(
            tooltip: 'Share PDF',
            onPressed: () => createAndSharePdf(record),
            icon: const Icon(Icons.picture_as_pdf),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Center(
            child: Icon(Icons.landscape, size: 64),
          ),
          const SizedBox(height: 8),
          const Center(
            child: Text(
              'RUDAR SURVEYOR',
              style: TextStyle(
                fontSize: 25,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(height: 22),
          DetailTile(label: 'માલિકનું નામ', value: record.owner),
          DetailTile(label: 'ગામ', value: record.village),
          DetailTile(label: 'તાલુકો', value: record.taluka),
          DetailTile(label: 'સર્વે નંબર', value: record.surveyNo),
          DetailTile(label: 'તારીખ', value: record.date),
          DetailTile(label: 'પેમેન્ટ', value: record.payment),
          DetailTile(label: 'મોબાઇલ નંબર', value: record.mobile),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: () => createAndSharePdf(record),
            icon: const Icon(Icons.share),
            label: const Text('PDF બનાવો અને Share કરો'),
          ),
        ],
      ),
    );
  }
}

class DetailTile extends StatelessWidget {
  final String label;
  final String value;

  const DetailTile({
    super.key,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        title: Text(
          label,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Text(value.isEmpty ? '-' : value),
      ),
    );
  }
}

Future<void> createAndSharePdf(SurveyRecord record) async {
  final document = pw.Document();

  document.addPage(
    pw.Page(
      pageFormat: PdfPageFormat.a4,
      build: (context) {
        return pw.Padding(
          padding: const pw.EdgeInsets.all(30),
          child: pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Center(
                child: pw.Text(
                  'RUDAR SURVEYOR',
                  style: pw.TextStyle(
                    fontSize: 25,
                    fontWeight: pw.FontWeight.bold,
                  ),
                ),
              ),
              pw.SizedBox(height: 8),
              pw.Center(
                child: pw.Text(
                  'LAND SURVEY REPORT',
                  style: const pw.TextStyle(fontSize: 15),
                ),
              ),
              pw.Divider(),
              pw.SizedBox(height: 20),
              pdfRow('Owner Name', record.owner),
              pdfRow('Village', record.village),
              pdfRow('Taluka', record.taluka),
              pdfRow('Survey Number', record.surveyNo),
              pdfRow('Date', record.date),
              pdfRow('Payment', record.payment),
              pdfRow('Mobile Number', record.mobile),
              pw.Spacer(),
              pw.Divider(),
              pw.Center(
                child: pw.Text(
                  'Customer Care: Y.M. DHUNDHALAVA | 8487847474',
                  style: const pw.TextStyle(fontSize: 10),
                ),
              ),
            ],
          ),
        );
      },
    ),
  );

  final bytes = await document.save();

  await Printing.sharePdf(
    bytes: bytes,
    filename: 'RUDAR_SURVEYOR_${record.surveyNo.isEmpty ? 'Report' : record.surveyNo}.pdf',
  );
}

pw.Widget pdfRow(String label, String value) {
  return pw.Padding(
    padding: const pw.EdgeInsets.only(bottom: 12),
    child: pw.Row(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.SizedBox(
          width: 145,
          child: pw.Text(
            label,
            style: pw.TextStyle(fontWeight: pw.FontWeight.bold),
          ),
        ),
        pw.Expanded(child: pw.Text(value.isEmpty ? '-' : value)),
      ],
    ),
  );
}

class CalculatorScreen extends StatefulWidget {
  const CalculatorScreen({super.key});

  @override
  State<CalculatorScreen> createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> {
  final length = TextEditingController();
  final width = TextEditingController();

  double result = 0;

  void calculate() {
    final l = double.tryParse(length.text) ?? 0;
    final w = double.tryParse(width.text) ?? 0;

    setState(() {
      result = l * w;
    });
  }

  @override
  void dispose() {
    length.dispose();
    width.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('જમીનનું Calculator'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Text(
            'જમીનનું ક્ષેત્રફળ Calculator',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 20),
          TextField(
            controller: length,
            keyboardType:
                const TextInputType.numberWithOptions(decimal: true),
            decoration: InputDecoration(
              labelText: 'Length (Meter)',
              prefixIcon: const Icon(Icons.straighten),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
              ),
            ),
          ),
          const SizedBox(height: 15),
          TextField(
            controller: width,
            keyboardType:
                const TextInputType.numberWithOptions(decimal: true),
            decoration: InputDecoration(
              labelText: 'Width (Meter)',
              prefixIcon: const Icon(Icons.swap_horiz),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
              ),
            ),
          ),
          const SizedBox(height: 20),
          SizedBox(
            height: 54,
            child: FilledButton.icon(
              onPressed: calculate,
              icon: const Icon(Icons.calculate),
              label: const Text(
                'Calculate',
                style: TextStyle(fontSize: 18),
              ),
            ),
          ),
          const SizedBox(height: 25),
          Card(
            elevation: 3,
            child: Padding(
              padding: const EdgeInsets.all(25),
              child: Column(
                children: [
                  const Text(
                    'કુલ વિસ્તાર',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    '${result.toStringAsFixed(2)} ચો. મીટર',
                    style: const TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          const Center(
            child: Text(
              'Example: 25 m × 40 m = 1000 ચો. મીટર',
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }
}
